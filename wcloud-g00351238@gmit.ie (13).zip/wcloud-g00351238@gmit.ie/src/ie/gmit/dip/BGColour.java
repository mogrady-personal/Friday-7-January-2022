package ie.gmit.dip;

/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * 
 * Simple Enum with Get/Set methods for WCloud Background.
 *
 * Enum with Get/Set methods for background colour options available for use with the WCloud Background.
 *
 */

/**
 * Enum to store and return Background colours for Word Cloud Image Background.
 */
public enum BGColour {
	
	/**
     * Black Option HEX #000000: 
     */
	BLACK("#000000"), 
	/**
     * White Option HEX #FFFFFF: 
     */
	WHITE("#FFFFFF");

	/**
     * Return background hex colour as string colour
     */
	private final String colour;
	/**
	 * Set Background Colour
	 * @param string colour
	 */
	BGColour(String colour) {
		this.colour = colour;
	}
	/**
	 * Return Background Colour
	 * @return string
	 */
	public String colour() {
		return colour;
	}
}
