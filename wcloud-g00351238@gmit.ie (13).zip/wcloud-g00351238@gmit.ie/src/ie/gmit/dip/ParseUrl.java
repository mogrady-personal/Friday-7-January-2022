package ie.gmit.dip;
/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * jsoup: Java HTML Parser - Java library for working with HTML.
 *  Using Jsoup API fetch URLs and enable the parsing of data using selector-syntax to add to String array.
 *
 *
 */

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;

/**
 * Parsing of data through http using HTML selector-syntax. 
 * @author Michael
 *
 */
public class ParseUrl extends Parser {
	/* Idea and concept for url parsing using the Jsoup Libary by finding elements using a CSS or jquery-like selector syntax.
	 *  https://www.youtube.com/watch?v=wzh5TCVnWZQ
	 *  https://zetcode.com/java/jsoup/
	 *  Selector Syntax reference -> https://jsoup.org/cookbook/extracting-data/selector-syntax
	 */ 
	
	/**
	 * Jsoup HTTP URL parse method.
	 * 
	 */
    @Override
    public void parse(String url) throws IOException {
        Document doc = Jsoup.connect(url).get();

        // Use the following html selectors to parse content.
        String content = doc.select("h1, h2, h3, h4, h5, h6, p").text();

        // Split and lower case parsed content into String array
        String[] words = content.toLowerCase().split(" ");
        // Filter punctuation from words
        wordProcessor(words);
        // Add words to Set
        sortMap();
    }
}
