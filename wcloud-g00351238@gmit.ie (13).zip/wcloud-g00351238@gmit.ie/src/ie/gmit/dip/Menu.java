package ie.gmit.dip;

/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * 
 * Class Menu responsible for all method calls with and instance variables relating to the generation of the WCloud, including word count.
 * Instantiation through runner class, contains HashMap for menu option selection, Jsoup helper methods and additional functionality added to enable custom file saving options.
 *
 */

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 * Main class to instantiates methods.
 * 
 * @author Michael
 *
 */
public class Menu {
	
	/**
	 * Single console method to retrieve user input
	 * 
	 */
	private static final Scanner in = new Scanner(System.in);
	// Source Code adapted from -> (https://www.geeksforgeeks.org/hashmap-put-method-in-java/)
	/**
	 * HashMap implemented Menu -> Commands driven by Functional Interface
	 * 
	 */
	private final Map<Character, MenuCommandInterface> options = new HashMap<>();
	// Instance Variables
	/**
	 * Default Word Count is 30 words
	 */
	private static final int DEFAULT_WORD_COUNT = 30; // Default Setting
	/**
	 * Abstract class responsible for parsing ignore words and input/output
	 */
	private Parser parser;
	/**
	 * Input Source For Parsing
	 */
	private InputSource inputSource; // File / URL
	/**
	 * Console user Input
	 */
	private String consoleInput; // User Console Selection
	/**
	 * File/URL to Parse
	 */
	private String fileName; // URL or / File [as String]
	/**
	 * Accessible Variable to update maxWords
	 */
	private int maxWords = DEFAULT_WORD_COUNT;

	/**
	 * Program information with instantiation of new menu Object and Method calls.
	 * 
	 * @return menu
	 */	
	public static Menu mainMenu() {
		/**
		 * Print Application Information, Create new instance of Menu object to
		 * instantiate methods.
		 */
		System.out.println("***************************************************");
		System.out.println("* GMIT - Dept. Computer Science & Applied Physics *");
		System.out.println("*                                                 *");
		System.out.println("*                Word Cloud Generator             *");
		System.out.println("*     H.Dip in Science (Software Development)     *");
		System.out.println("*                                                 *");
		System.out.println("***************************************************");
		// Instantiate new Menu
		Menu menu = new Menu();
		// Determine Source of Text
		menu.sourceChoice();
		// Determine Input Type
		menu.srcType();
		// Set a default file name
		menu.setDefaultFileName();
		return menu;
	}

	/**
	 * Prompt user for method selection through do while loop
	 */
	private void sourceChoice() {
		int input;
		do {
			System.out.print("Select Source to Parse Text from: \n");
			System.out.println("1) Text File");
			System.out.println("2) URL");
			input = in.nextInt();
		} while (input != 1 && input != 2);
		if (input == 1) {
			// Retrieve inputSource from Enum and set as inputSource
			inputSource = InputSource.FILE;
			// Instantiate new ParseFile
			parser = new ParseFile();
		} else {
			inputSource = InputSource.URL;
			parser = new ParseUrl();
		}
	}
	
	/**
	 * Method caller to get and set url location or file directory path..
	 */
	private void srcType() {
		// Assert source type from menu choice
		if (inputSource == InputSource.FILE) {
			inputFile();
		} else {
			inputUrl();
		}
	}
	
	/**
	 * Prompt user for file name and directory path through Scanner.
	 */
	private void inputFile() {
		Scanner sc = new Scanner(System.in);
		// Loop used to guarantee successful input
		while (true) {
			System.out.print("Enter Path to Input File (including file extension): ");
			String userInput = sc.nextLine().trim();
			// Verify file is valid and "normal" (isFile())
			if (new File(userInput).isFile()) {
				// Assign source as file
				consoleInput = userInput;
				return;
			} else {
				System.out.printf("\"%s\" not found... please retry.\n", userInput);
			}
		}
	}
 
	/**
	 * Display menu options by means of a Hash Map with key
	 *
	 */
	private Menu() {// 0(1) Add key to hash map
		/*
		 * Code and Concept for HashMap key-value pair Menu adapted from:
		 * Week 8 Sets and Maps J.Healy 
		 */
		options.put('A', this::wCloudGenerator);
		options.put('B', this::setWordCount);
		options.put('C', this::setFileName);
		options.put('D', () -> System.exit(0));
	}

	/**
	 * Display menu with option selection for user through Scanner.
	 */
	public void menuChoice() {
		// Print Application Options on the Console for the User
		System.out.println("\nA) Generate Word Cloud");
		System.out.println("B) Set Maximum Number of Words to Display");
		System.out.println("C) Set Custom File Name of Word Cloud Image" );
		System.out.println("D) Quit ");

		while (true) { // O(1)  Retrieve element with key value from HashMap
			System.out.print("\nSelect an option listed above: ");
			char option = in.next().toUpperCase().charAt(0);
			// Access options; use interface with key-value map for menu 
			MenuCommandInterface cmd = options.getOrDefault(option,
					() -> System.out.println("[>] Please choose from one of the available options."));
			cmd.execute();
			if (option == 'A')
				return;
		}
	}
	
	/**
	 * Regex used for purposes of removing invalid characters from a string after file saving after w-cloud generation. 
	 * 
	 * @param string fileName
	 * @return a string
	 * 
	 */
	private static String removeInvalidChars(String filename) {
		// https://stackoverflow.com/questions/31563951/removing-invalid-characters-from-a-string-to-use-it-as-a-file/31564206#31564206
		// Replace with underscores
		return filename.replaceAll("[\\\\\\\\/:*?\\\"<>|]\"", "_");
	}

	/**
	 * URL parsing; recommended function for use with Jsoup
	 */
	private void inputUrl() {
		// Source Code adapted from -> https://jsoup.org/ & https://zetcode.com/java/jsoup/
		// Loop used to guarantee successful input
		while (true) {
			System.out.print("Enter the URL to parse: ");
			// Get URL from user, remove leading and trailing space from input
			String url = in.next().trim();
			// Recommended validation check for use with Jsoup -> concept and source: https://stackoverflow.com/questions/9607903/get-domain-name-from-given-url
			if (!url.startsWith("http://") && !url.startsWith("https://")) {
				// If the user inputed URL does not contain http:// or https:// -> add it.
				url = "http://" + url;
			}
			// Try catch block to connect to the remote object as referred to by URL.
			// Code adapted from http://www.java2s.com/example/java-api/java/net/url/openconnection-0-47.html
			try {
				System.out.println("Connecting to source...");
				// Open a communication link to the resource url
				new URL(url).openConnection().connect();
			} catch (IOException ex) {
				System.out.println("[ERROR] Unable connect to " + url
						+ "\nCheck network connection and ensure the URL entered is valid.\n" + ex);
				continue;
			}
			// Assign source as url
			consoleInput = url;
			return;
		}
	}

	/**
	 * Set a default file name for generated image through filename or document title should the user not opt to choose a name.
	 */
	private void setDefaultFileName() {
		if (inputSource == InputSource.FILE) {
			// Goal -> Set file name to be based input src filename as default.
			if (consoleInput.contains(".")) {
				// apply regex to inputSource filename & concatenate substring(filename) after . with .png.
				fileName = removeInvalidChars(consoleInput.substring(0, consoleInput.lastIndexOf('.')) + ".png");
			} else {
				// set file name based on user input & concatenate with .png.
				fileName = removeInvalidChars(consoleInput + ".png");
			}
		} else {
			// Run try/catch block, make sure Jsoup image parsing libary is available. Set the name the of image file to the pages title.
			try {
				// Code adapted from -> https://zetcode.com/java/jsoup/
				// Use Jsoup libary and connect to the url
				Document doc = Jsoup.connect(consoleInput).get();
				// Parse the filename from the doc.title removing invalid chars through regex, trimming white space to use as the filename.
				fileName = removeInvalidChars(doc.title() + ".png").trim();
			} catch (NoClassDefFoundError e) {
				// note: The Jsoup libary is a dependency and is required to parse URL
				System.out.println(
			"[ERROR] To parse a URL jsoup.jar libary is required to be run together along with main jar file. Please ensure jsoup file is located in the correct directory.");
				// Exit application
				System.exit(0);
			} catch (Exception e) {
				// Set default image name should an exception occur.
				fileName = "WCloud.png";
			}
		}
	}
	
	/**
	 * Set a custom file name for generated image should user opt to choose a file name for the word cloud.
	 */
    private void setFileName() {
        Scanner sc = new Scanner(System.in);
		// Loop to guarantee successful input
        while (true) {
        	// Retrieve the default file name parsed from either URL or file
            System.out.printf("Enter name to save the Word Cloud Image (current is \"%s\"): ", fileName);
            String input = sc.nextLine().trim();
            // Set file name
            if (!input.isEmpty()) {
            	fileName = removeInvalidChars(input); 
            	// Validation check for file name
                if (fileName.contains(".")) {
                	// Append png to the last index of . substring
                	fileName = fileName.substring(0, fileName.lastIndexOf('.')) + ".png";
                } else {
                	// Append png to filename
                	fileName += ".png";
                }
                System.out.println("Updated file name...");
                return;
            }
        }
    }
    

	/**
	 * Set limit on the maximum number of words to display as defined in instance
	 * variables.
	 */
	private void setWordCount() {
		// retrieve preset maxWords integer
		int maxWords = this.maxWords;
		// set do while loop to ensure successful input on positive integer
		boolean loop = true;
		do {
			// Try catch check for validated input
			try {
				// Display currently set max word count
				System.out.printf("Set maximum words for Word Cloud (current is %d): ",
						maxWords);
				// Validation check to ensure entered number is positive value
				// Concept -> https://www.geeksforgeeks.org/java-math-abs-method-examples/
				maxWords = Math.abs(in.nextInt());
			} catch (InputMismatchException e) {
				// Error handling for invalid input 
				System.out.println("[ERROR] Must be a postive integer!");
				in.next();
				continue;
			}
			loop = false;
		} while (loop);
		// Update with new Max Words limit
		this.maxWords = maxWords;
	}
	
	/**
	 * Try catch block implements generation of word cloud. Parsing of ignorefile
	 * with true false option of output word frequency to file.
	 * 
	 */
	private void wCloudGenerator() {
		// Main Function for Cloud Generation using try catch block
		try {
			/* Order of Process
			 * 1) Parse in ignore words file into HashSet
			 * 2) Parse from File/URL into HashMap 
			 * 3) Find Frequency of words by using Counter
			 * 4) Add Words and Frequency to Priority Queue
			 * 5) Strip Punctuation, Sort Words and Frequency
			 * 6) Update HashMap using containsKey and put
			 * 7) Request Export of Frequency Table to a txt file
			 * 7) Generate Word cloud png file
			 */
			// Locate the ignore file and parse into HashSet
			parseIgnoreFile();
			// Prompt to print Frequency table of words
			System.out.print("\nDo you want to print a frequency table to a text file ? (y/n) ");
			// Convert user input to upper case and look at first char, if == y then (true)
			boolean freqTable = Character.toUpperCase(in.next().charAt(0)) == 'Y';
			//  https://www.javatpoint.com/java-program-to-find-the-frequency-of-each-element-in-the-array
			// Start counter to determine time it takes to generate word cloud.
			long start = System.currentTimeMillis(); 
			parser.parse(consoleInput);
			Queue<FrequencyTable> wordQ = parser.getWordQueue();
			// If true, then assign frequency table file naming convention here.
			if (freqTable) {
				String filename = fileName.substring(0, fileName.lastIndexOf('.')) + "_Frequency_Table.txt";
				parser.outputWriter(filename, maxWords);
			}
			GenerateImage ig = new GenerateImage.WCloudBuilder().build();
			ig.drawWords(wordQ, maxWords);
			ig.writer(fileName);
			
			// Output count of words retrieved from parser and time taken to parse content and create WCloud.
			System.out.printf("\n%d unique words parsed from " + consoleInput + " in %.2f (ms).\n", parser.getWordFreq(), timer(start)); 
			// Open the Image File in the Default Image Viewer
			openImgFile();
		} catch (IOException e) {
			System.err.println("[ERROR] IO Exception ERROR.\n"+e);
			e.printStackTrace();
		}
	}
	
	/**
	 * Returns length of time it takes in seconds to generate word cloud.
	 * 
	 * @param double startTime
	 * @return double
	 * 
	 */
	private static double timer(long start) {
		return (System.currentTimeMillis() - start) ;
	}

	/**
	 * Try catch block implements parsing of ignore file into HashSet
	 * 
	 */
	private void parseIgnoreFile() {
		// Locate the ignore file using try catch block
		try {
			// Parse ignore file adding words to set
			parser.ignoreFileParser();
		} catch (IOException e) {
			// Ignore file not found within the project directory
			System.out.printf("[ERROR] No \"%s\" file was found. Proceed anyway ? (y/n) ", Parser.IGNORE_FILE);
			if (Character.toUpperCase(in.next().charAt(0)) != 'Y') {
				System.exit(0);
			}
		}
	}

	/**
	 * Java Desktop class used to launch associated applications on the native
	 * desktop to handle a URI or a file. <b>Method prompts option to open the output
	 * file in default image application viewer.</b>
	 * 
	 */
	private void openImgFile() {
		/*
		 * isDesktopSupported -> Concept and Code from: 
		 * https://www.programcreek.com/java-api-examples/?class=java.awt.Desktop&method
		 * =isDesktopSupported
		 * 
		 */
		if (new File(fileName).isFile()) {
			System.out.print("\nOpen In Default Image Viewer ?(y/n)? ");
			// Retrieve input string from user, convert to uppercase; if first character is (Y) 
			if (Character.toUpperCase(in.next().charAt(0)) == 'Y') {
				// Tests whether this class is supported on the current platform.
				// https://download.java.net/java/GA/jdk14/docs/api/java.desktop/java/awt/Desktop.html
				if (Desktop.isDesktopSupported()) {
					try {
						// Open file in the default image viewer
						Desktop.getDesktop().open(new File(fileName));
					} catch (IllegalArgumentException e) {
						System.out.printf("[ERROR] Cannot open file");
					} catch (UnsupportedOperationException e) {
						System.out.printf(
								"[ERROR] Function not supported.\n"+e);
					} catch (Exception e) {
						System.out.printf("[ERROR] Cannot open the file"+e);
					}
				} else {
					System.out.printf("[ERROR] Cannot open the file \"%s\". Functionality unsupported.\n", fileName);
				}
			}
		}
		System.out.println("\nThank you for using the Word Cloud Generator..");
	}

}