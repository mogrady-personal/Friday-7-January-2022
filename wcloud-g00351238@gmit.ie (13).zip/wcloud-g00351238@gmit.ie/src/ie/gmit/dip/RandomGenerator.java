package ie.gmit.dip;

/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * 
 * Helper class to assist the generation of random integers for image sizing.
 *
 */

import java.util.concurrent.ThreadLocalRandom;

/**
 * Static helper class to generate random numbers.
 */
public final class RandomGenerator {
/* 
 * Concept for random number generation using ThreadLocalRandom API used for colour selection:
 * https://docs.oracle.com/javase/7/docs/api/java/util/concurrent/ThreadLocalRandom.html
 * https://stackoverflow.com/questions/23396033/random-over-threadlocalrandom
 * https://www.youtube.com/watch?v=2aK9ZDI98P8

 * Random number required to apply a random font family, font style, and Colour Palette
 * 
 */

	/**
	 * Return a random number between a specified min and max.
	 */
	public static int generate(int min, int max) {
		return ThreadLocalRandom.current().nextInt(min, max + 1);
	}

	/**
	 * Return a random number between 0 and specified max.
	 * 
	 * @param int max
	 * @return Int
	 */
	public static int generate(int max) {
		return generate(0, max);
	}

	/**
	 * Generate a type of integer array and generate random number from 0 to
	 * arr.length-1
	 * 
	 * @param <T> Int max
	 * @return Int []
	 * 
	 */
	public static <T> int generate(T[] arr) {
		return generate(0, arr.length - 1);
	}
	/**
	 * Return String Array of colour values from Enum
	 * for word colouring. Word colours are decided by random number (based on
	 * integers) generator
	 * 
	 */
	public static String[] generateWordColours() {
		ColourPalettes[] values = ColourPalettes.values();
		// Return Randomly Selected Colour Palette
		return values[RandomGenerator.generate(values.length - 1)].list();

	}
}
