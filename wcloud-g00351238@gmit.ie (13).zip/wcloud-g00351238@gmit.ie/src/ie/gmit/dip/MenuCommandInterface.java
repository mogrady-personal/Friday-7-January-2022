package ie.gmit.dip;
/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * 
 * Interface MenuCommand contains single abstract (unimplemented) execute method.
 *
 */

/**
 * Menu Command Functional Interface
 *
 */
@FunctionalInterface
public interface MenuCommandInterface {
	    void execute();
}
