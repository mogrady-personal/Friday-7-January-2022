package ie.gmit.dip;
/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * Word Class Implements Java Comparable interface.
 * Getter/setter and override methods to return word,  frequency count and compare method.
 *
 */

/**
 * Java Comparable interface using getter/setter and override methods to return word,  frequency count and compare method.
 * @author Michael
 *
 */
public class FrequencyTable implements Comparable<FrequencyTable> {
//	Concept and Code adapted from -> https://stackoverflow.com/questions/10158793/sorting-words-in-order-of-frequency-least-to-greatest
//	Count word frequency in Java -> https://www.javacodemonk.com/count-word-frequency-in-java-e6c2918a
	/**
	 * Instance variable to return word as String.
	 */
    private final String word;
	/**
	 * Instance variable to return frequency of word as Integer.
	 */
    private final int frequency;

   /**
    * Set word and frequency of word.
    * @param word
    * @param frequency
    * @return String
    * @return Int
    */
    public FrequencyTable(String word, int frequency) {
        this.word = word;
        this.frequency = frequency;
    }
    
    /**
     * Return word as String.
     * @return String
     */
    public String getWord() {
        return word;
    }
    /**
     * Return word frequency as Integer
     * @return Int
     */
    public int getFrequency() {
        return frequency;
    }
    /**
     * toString Override method to return frequency and word for the frequency table.
     */
    @Override
    public String toString() {
        return frequency + "  " + word;
    }

    /**
     * Override method to compare word to return word frequency.
     */
    @Override
    public int compareTo(FrequencyTable word) {
        return -Integer.compare(frequency, word.frequency);
    }
}
