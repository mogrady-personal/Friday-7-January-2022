package ie.gmit.dip;
/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * 
 *  Main Class responsible implementing generating the background colour and word colouring based on values from random number generator.
 *
 */

/**
 *  Set background colour from future expandable Enum selection in BGColour.
 */
public class Background {
	/**
	 * Set Background Colour.
	 * 
	 * @return bg
	 * 
	 */
	private static BGColour bg = BGColour.WHITE;
	/**
	 * Return background colour from getBackgroundColour method 
	 * 
	 */
	public static String getBackgroundColour() {
		return bg.colour();
	}

}
