package ie.gmit.dip;
/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * 
 * Main Method Runner Class -> create instance of Menu methods.
 *
 */

/**
 * Runner class with Main Method to start application.
 * @param args
 */
public class Runner {
	public static void main(String[] args) {
//		Create new Instance of mainMenu
        Menu menu = Menu.mainMenu();
        // Run menuChoice
        menu.menuChoice();
	}
}
