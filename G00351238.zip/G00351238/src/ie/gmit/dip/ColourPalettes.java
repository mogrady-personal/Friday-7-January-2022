package ie.gmit.dip;

/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * 
 *        Enum containing a list of colour palette and hex values accessible for the 
 *        image generator.
 *        Source of palettes https://www.color-hex.com/color-palettes/
 *
 */

/**
 * Enum selection of colour palettes in hex values made available to the random number generator and accessable through ColourPalettes().
 * 
 */
public enum ColourPalettes {
	Stuffed_Animal_Palette("#ff0000", "#ff6600", "#ffcc00", "#ccff00", "#66ff00"),
	/**
	 * "#19cc65", "#1b69a7", "#4542f9", "#850fca", "#ec03fa"
	 */
	Mookie_Monster_Color_Palette("#19cc65", "#1b69a7", "#4542f9", "#850fca", "#ec03fa"),	
	/**
	 * "#0c89b6", "#512878", "#cca735", "#ed290b", "#3fd100"
	 */
	Space_Colours_Color_Palette("#0c89b6", "#512878", "#cca735", "#ed290b", "#3fd100"),
	/**
	 * "#2dc521", "#97d258", "#9a69b3", "#1c97e1", "#f1f024"
	 */
	Sea_life_Color_Palette("#2dc521", "#97d258", "#9a69b3", "#1c97e1", "#f1f024"),
	/**
	 * "#0c2074", "#8519ab", "#6e229c", "#f4fb60", "#feb418"
	 */
	Gmit_Sample_Palette("#0c2074", "#8519ab", "#6e229c", "#f4fb60", "#feb418"),
	/**
	 * "#003f87", "#fcd856", "#d62828", "#ffffff", "#007a3d"
	 */
	Seychelles_Color_Palette("#003f87", "#fcd856", "#d62828", "#ffffff", "#007a3d");
	
/**
 * Array of Strings list, list of Colours from the Palette to apply for a word cloud.
 */
	private final String[] list;
/**
 *   Create new String literal array to define word colours.  
 * @param list
 */
	ColourPalettes(String... list) {
		this.list = new String[list.length];
		System.arraycopy(list, 0, this.list, 0, list.length);
	}

	/**
	 * Return string array of Colour palette
	 * 
	 * @param string[] list
	 * @return string
	 * 
	 */
	public String[] list() {
		return list;
	}
}
