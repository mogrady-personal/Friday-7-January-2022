package ie.gmit.dip;
/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * 
 * Enum of file types available for image processing.
 *
 */

/**
 * Input Source options defined within Enum. 
 * Support for a) reading image through buffered reader from txt file on local machine or b) through html via http request using Jsoup API.
 *
 */
public enum InputSource {
	/**
	 * Support for reading from txt file on local machine.
	 */
    FILE,
	/**
	 * Support for reading from url across http.
	 */
    URL
}
