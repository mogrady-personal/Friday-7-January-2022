package ie.gmit.dip;

/**
 * 
 * @author Michael
 * @version 1.6
 * @since 1.8
 * 
 * 
 * Interface extending Parser class for reading text from a character-input stream using Buffered Reader API.
 *
 */


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Reads in Ignore File, abstraction extends Parser class for reading in text from a character-input stream.
 * 
 * @author Michael
 *
 */
public class ParseFile extends Parser {
	/**
	 * Read words parsed through buffered reader creating String array.
	 */
	@Override
	public void parse(String path) throws IOException { // 0(1) Parsing of text through Buffered Reader
		// Read in the words from the input file
		try (BufferedReader inputFile = new BufferedReader(new FileReader(path))) {
			String next;
			// Read each line of text turning into lowercase and split by space
			while ((next = inputFile.readLine()) != null) {
				// Add every word in each line of the file to an array, using spaces as delimiters.
				String[] words = next.toLowerCase().split(" ");
				// Process words within parser
				wordProcessor(words);
			}
			sortMap();
		}
	}
}
