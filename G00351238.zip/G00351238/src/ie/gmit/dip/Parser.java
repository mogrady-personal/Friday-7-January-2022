package ie.gmit.dip;

/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * 
 * Parser Abstract Class for Parser Implementing Hash Map, Sets and Queues for returning frequency count and adding of words to the queue. 
 * Fixed location for specified ignorewords file located in project directory.
 */

import java.io.BufferedReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.io.FileNotFoundException;

/**
 * Abstract class responsible for parsing ignore words and input/output from
 * buffered reader to Hash Map. Strips punctuation, defines frequency table and
 * ignore words. Required for both URL and file input types
 * 
 * @author Michael
 *
 */
public abstract class Parser {
	/**
	 * Ignore words file for word cloud expected to be called ignorewords.txt within project directory.
	 */
	public static final String IGNORE_FILE = "ignorewords.txt";
	/**
	 * Hash Set used to load in ignore words.
	 */
	private final Set<String> ignoreWords = new HashSet<>();
	/**
	 * Map of key value pairs for word frequency stored in Hash Map.
	 */
	private final Map<String, Integer> uniqueWords = new HashMap<>();
	/**
	 * Collection of words for frequency table.
	 */
	private final Queue<FrequencyTable> wordQueue = new PriorityQueue<>();
	/**
	 * Returns collection of words for processing by buffered reader.
	 * 
	 * @return wordQueue
	 */
	public Queue<FrequencyTable> getWordQueue() {
		return wordQueue;
	}
	
	/**
	 * Return number of key-value mappings in Map as integer to determine size of collection.
	 * 
	 * @param int uniqueWords
	 * @return int
	 * 
	 */
	public int getWordfQueueFreq() {
		// Return words parsed from file/url and count
		return wordQueue.size();
	}

	/**
	 * Return number of key-value mappings in Map as integer to determine size of collection.
	 * 
	 * @param int uniqueWords
	 * @return int
	 * 
	 */
	public int getWordFreq() {
		// Return frequency of unique words as int
		return uniqueWords.size();
	}
	
	/**
	 * Return number of key-value mappings of ignore words in HashSet as integer to determine size of collection.
	 * 
	 * @param int ignoreWords
	 * @return int
	 * 
	 */
	public int getIgnoreWordsCount() {
		// Return number of ignore words as int
		return ignoreWords.size();
	}


	/**
	 * Abstract parsed string for accessibility.
	 * 
	 * @param string
	 * @throws IOException
	 */
	public abstract void parse(String string) throws IOException;

	/**
	 * 
	 * Parse ignore words file to HashSet convert each word to lower case and add to Hash
	 * Table.
	 * 
	 */
	public void ignoreFileParser() throws IOException { // O(1) (Insertion) Parse ignore Words Hash Set adds elements in random location
		// Expected directory for the ignorefile within the project directory (hardcoded)		
		try (BufferedReader ignoreFile = new BufferedReader(new FileReader("./" + IGNORE_FILE))) {
			String next;

			long start = System.currentTimeMillis(); 
			while ((next = ignoreFile.readLine()) != null) {
				// Remove trailing space for each word 
				if (next.trim().isEmpty())
					continue;
				// Then add elements to HashSet O(1) in lowercase
				ignoreWords.add(next.toLowerCase());
			}
			// Running time in ms of the parsing of the ignore words file and adding into HashSet
			System.out.printf("\n%d unique ignore words parsed from " + IGNORE_FILE +" in %.2f (ms).\n", getIgnoreWordsCount(), timer(start)); 
		}
	}
	
	/**
	 * Returns length of time it takes in ms to parse in ignore file and add to HashSet
	 * 
	 * @param double startTime
	 * @return double
	 * 
	 */
	private static double timer(long start) {
		return (System.currentTimeMillis() - start);
	}
	

	/**
	 * Foreach loop to manipulate array. Trim and strip punctuation from each word
	 * from String array of words parsed.
	 * 
	 * @param string[] words
	 * @return string
	 */
	protected void wordProcessor(String[] words) { // O(n) (Insertion) Hash Map for loop
		// Required to clean input words for both the URL and file
		for (String word : words) {
			// For each word, use regex to extract punctuation and white space
			word = stripPunctuationwithRegex(word).trim();
			// Only add words to set where they are not ignore words O(n)
			if (!ignoreWords.contains(word)) {
				if (!word.isEmpty()) {
					updateMap(word);
				}
			}
		}
	}
	/**
	 * Strip of punctuation from parsed words using regex.
	 * 
	 * @param string word
	 * @return string
	 * 
	 */
	private static String stripPunctuationwithRegex(String word) {
		// https://stackoverflow.com/questions/43171774/how-to-remove-exterior-punctuation-from-a-string-using-regular-expressions
		return word.replaceAll("(?:(?<!\\S)\\p{Punct}+)|(?:\\p{Punct}+(?!\\S))", "");
	}
	
	/**
	 * *PrintWriter API* used to sort output words from queue to file implementing
	 * Java Compar*able* interface.
	 * 
	 * @param int    numWords
	 * @param string filename
	 * 
	 */
	public void outputWriter(String filename, int numWords) throws FileNotFoundException {
		try (PrintWriter pw = new PrintWriter(filename)) {
			int counter = 0;
			// Add elements from FrequencyTable to priority queue counter over length of queue.
			// Concept and Code adapted from -> https://www.javacodemonk.com/count-word-frequency-in-java-e6c2918a
//			long start = System.currentTimeMillis(); 
			Queue<FrequencyTable> freq = new PriorityQueue<>(wordQueue); 					//  O(log n) Add to PriorityQueue
			while (counter < freq.size() && counter < numWords) {
				// Retrieves and removes the head of this queue,or returns null if this queue is empty.
				pw.println(freq.poll()); 													// O(log n)  Retrieves and removes the head of this queue
				counter++;
			}
			// Option to Print Unique Words from file/url and output parsing time in ms
//			System.out.printf("\n%d unique words parsed from " + wordQueue +" in %.2f (ms).\n", getWordfQueueFreq(), timer(start)); 
		}
	}

	/**
	 * For each word in the Hash Map, add to PriorityQueue. Sort word each time new
	 * element is added based on frequency order.
	 */
	protected void sortMap() { // O(1) HashMap get with sort by Key (word)
		// Iterate over each of the keys in the Set, instantiate a new Word object with key and add to PriorityQueue.
		for (String key : uniqueWords.keySet()) {
			// Create collection of words for freq table
			wordQueue.offer(new FrequencyTable(key, uniqueWords.get(key)));
		}
	}

	/**
	 * Search for occurrence of string in Hash Map count frequency and increment.
	 * 
	 * @param string word
	 * @return string
	 * 
	 */
	private void updateMap(String word) { // O(1) HashMap get with Key word
		// If word exists in Hash Map, frequency is retrieved and incremented.
		if (uniqueWords.containsKey(word)) {
			int freq = uniqueWords.get(word);
			// Add each unique word and increment frequency Running Time: O(n)
			uniqueWords.put(word, ++freq);
		} else {
			// Initiate word frequency with one
			uniqueWords.put(word, 1);
		}
	}

}
