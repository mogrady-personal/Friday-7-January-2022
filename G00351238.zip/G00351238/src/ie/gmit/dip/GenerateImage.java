package ie.gmit.dip;

/**
 * 
 * @author Michael O'Grady
 * @version 1.6
 * @since 1.8
 * 
 * Main class for image generation functions implementing Java Comparable
 * interface for calculating word sizing, frequency, image, and font with getter
 * setter methods.
 *
 */

import javax.imageio.ImageIO;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Queue;
/**
 * Image generation class for using awt for graphics and creating Word Cloud using Collections.
 * Includes getter/setters.
 */
public class GenerateImage {
	// Concept and Code for Image Generator adapted from:
	// https://www.programcreek.com/java-api-examples/?api=javax.imageio.ImageWriter
	// https://www.youtube.com/watch?v=zCiMlbu1-aQ
	private final int imageWidth;
	private final int imageHeight;
	private final double minFontSize;
	private final double maxFontSize;
	private final String outputFormat;
	private final String[] fontFamilies;
	private final Integer[] fontStyles;
	private final BufferedImage image;

	/**
	 * Public function for access variables for the BufferedImage generator.
	 *
	 */
	public GenerateImage(WCloudBuilder builder) {
		// Concept Adopted from John Healy (Creating a PNG Image from Text)
		// Parameters to pass in for Image and Font specifics.
		imageWidth = builder.imageWidth;
		imageHeight = builder.imageHeight;
		minFontSize = builder.minFontSize;
		maxFontSize = builder.maxFontSize;
		outputFormat = builder.outputFormat;
		fontFamilies = builder.fontFamilies;
		fontStyles = builder.fontStyles;
		image = new BufferedImage(imageWidth, imageHeight, BufferedImage.TYPE_4BYTE_ABGR);
	}

	/**
	 * Image cloud writer function to take in queue of words and max words integer
	 * using ImageWriter and Graphics2D API's to output to new image file to path
	 * location.
	 *
	 * @param string path
	 * 
	 */
	public void drawWords(Queue<FrequencyTable> wordQueue, int maxWords) { // 0(1)
		// Concept for Image Generator using comparator for font sizing adopted from:
		// https://www.programcreek.com/java-api-examples/?api=javax.imageio.ImageWriter
		// Code for output word sizing adapted from:
		// https://www.youtube.com/watch?v=zCiMlbu1-aQ
		int max = 0;
		int min = 0;
		// Get the randomly generated colour
		String[] colour = RandomGenerator.generateWordColours();
		// Use Graphics2D library to draw BufferedImage
		Graphics2D graphics = image.createGraphics();
		// use setColor from convert String to integer and returns background colour.
		// https://docs.oracle.com/javase/7/docs/api/java/awt/Graphics.html
		graphics.setColor(Color.decode(Background.getBackgroundColour()));
		graphics.fillRect(0, 0, imageWidth, imageHeight);
		// Initialise the Word Frequency Counter
		// Concept from -> https://www.javatpoint.com/java-program-to-find-the-frequency-of-each-element-in-the-array
		int counter = 0;
		Iterator<FrequencyTable> i = wordQueue.iterator();
		// Loop over each word within collection 
		while (i.hasNext() && counter < maxWords) {  // O(log n)
			/* Get frequency using a counter for words to determine sizing of the words
			 * Compares each word and sizes depending on the frequency of word;
			 * higher the frequency, larger the word.
			 * Concept from -> https://www.javacodemonk.com/count-word-frequency-in-java-e6c2918a
			 */
			int j = i.next().getFrequency();
			if (j > max)
				max = j;
			if (j < min)
				min = j;
			// Run loop for while each word exists in queue && counter is less than maxWords.
			while (!wordQueue.isEmpty() && counter < maxWords) { 	
				// Source -> https://www.geeksforgeeks.org/queue-poll-method-in-java/
				// Returns and remove element at the front of queue works way through queue
				FrequencyTable word = wordQueue.poll(); 			// O (log n) as removes word from the top of the queue each loop
				// Apply random font style. 
				graphics.setFont(new Font(fontFamilies[RandomGenerator.generate(fontFamilies)],
				fontStyles[RandomGenerator.generate(fontStyles)], fontSizing(word.getFrequency(), min, max)));
				// Get random colour scheme and Apply colour. ( decode-> Converts a String to an integer and returns the specified opaque Colour )
				graphics.setColor(Color.decode(colour[RandomGenerator.generate(colour)]));
				/*
				 * Use java.awt.FontMetrics to Determine font sizing based on given word calculation function above.
				 * https://docs.oracle.com/javase/7/docs/api/java/awt/FontMetrics.html
				 * Concept and code adapted for getFontMetrics text sizing -> https://www.youtube.com/watch?v=n2UYy5IjpY8
				 */
				FontMetrics fm = graphics.getFontMetrics();
				// Generate word based on width of word minus image width
				int x = RandomGenerator.generate(imageWidth - fm.stringWidth(word.getWord()));
				// Generate word based on height of word 
				int y = RandomGenerator.generate(fm.getHeight(), imageHeight);
				// Draw string -> https://www.programcreek.com/java-api-examples/?class=java.awt.Graphics&method=drawString
				graphics.drawString(word.getWord(), x, y);
				counter++;
			}
		}
		// Dispose graphics context, release system resources
		graphics.dispose();
	}

	/**
	 * Image cloud writer function using ImageWriter API based on output to new File path location.
	 *
	 * @param string path
	 * @return string
	 */
	public void writer(String path) throws IOException {
		// Write buffered image to file
		ImageIO.write(image, outputFormat, new File(path));
	}

	/**
	 * Helper math function to scale word based on frequency generating an integer
	 * value.
	 * 
	 * @param double frequency
	 * @param double min
	 * @param double max
	 * @return int
	 */
	private int fontSizing(double frequency, double min, double max) {
		// Return integer to determine size of word dependent on word frequency
		return (int) Math.floor((maxFontSize - minFontSize) * (frequency - min) / (max - min) + minFontSize);
	}

	/**
	 * Instance variables for the specification of default image: size, fonts, style
	 * and type for word cloud generation.
	 * 
	 */
	public static class WCloudBuilder {
		// Concept for Image Generator adopted from:
		// https://www.programcreek.com/java-api-examples/?api=javax.imageio.ImageWriter
		// Code for output word sizing adapted from:
		// https://www.youtube.com/watch?v=zCiMlbu1-aQ
		// Image Sizing Specifics
		private int imageHeight = 700;
		private int imageWidth = 700;
		private String outputFormat = "png";
		// Font Specifics ( from Font Class  )
		private double maxFontSize = 100;
		private double minFontSize = 10;
		// Array of Font Style Options (integer)
		private Integer[] fontStyles = { Font.PLAIN, Font.BOLD, Font.ITALIC };
		// Array of fontFamilies (https://docs.oracle.com/javase/tutorial/2d/text/fonts.html#physical-fonts
		// private String fontFamilies[] = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
		// String Array of Font Families made available to generator
        private String[] fontFamilies = {Font.DIALOG, Font.DIALOG_INPUT, Font.SERIF, Font.SANS_SERIF, Font.MONOSPACED};
        
		/**
		 * Returns specific image height as integer value for image generation.
		 * 
		 * @param int value
		 * @return int
		 */
		public WCloudBuilder imageHeight(int value) {
			imageHeight = value;
			return this;
		}

		/**
		 * Returns specified maximum font size from instance variable.
		 * 
		 * @param int value
		 * @return int
		 */
		public WCloudBuilder imageWidth(int value) {
			imageWidth = value;
			return this;
		}

		/**
		 * Returns specified maximum font size from instance variable.
		 * 
		 * @param double value
		 * @return double
		 */
		public WCloudBuilder maxFontSize(double value) {
			maxFontSize = value;
			return this;
		}

		/**
		 * Returns specified minimum font size from instance variable.
		 * 
		 * @param double value
		 * @return double
		 */
		public WCloudBuilder minFontSize(double value) {
			minFontSize = value;
			return this;
		}

		/**
		 * Returns specified image type from instance variable.
		 * 
		 * @param string value
		 * @return string
		 */
		public WCloudBuilder outputFormat(String value) {
			outputFormat = value;
			return this;
		}

		/**
		 * Returns font styles from string of font families.
		 * 
		 * @param integer value
		 * @return integer
		 */
		public WCloudBuilder fontStyles(Integer... value) {
			fontStyles = value;
			return this;
		}

		/**
		 * Return string array of font family values.
		 * 
		 * @param string value
		 * @return string
		 */
		public WCloudBuilder fontFamilies(String... value) {
			fontFamilies = value;
			return this;
		}

		/**
		 * Return new instance of this Object.
		 * 
		 */
		public GenerateImage build() {
			return new GenerateImage(this);
		}
	}
}
