=========================================================================
 __      __                .___ _________ .__                   .___
/  \    /  \___________  __| _/ \_   ___ \|  |   ____  __ __  __| _/
\   \/\/   /  _ \_  __ \/ __ |  /    \  \/|  |  /  _ \|  |  \/ __ | 
 \        (  <_> )  | \/ /_/ |  \     \___|  |_(  <_> )  |  / /_/ | 
  \__/\  / \____/|__|  \____ |   \______  /____/\____/|____/\____ | 
       \/                   \/          \/                       \/ 
  ________                                   __                
 /  _____/  ____   ____   ________________ _/  |_  ___________ 
/   \  ____/ __ \ /    \_/ __ \_  __ \__  \\   __\/  _ \_  __ \
\    \_\  \  ___/|   |  \  ___/|  | \// __ \|  | (  <_> )  | \/
 \______  /\___  >___|  /\___  >__|  (____  /__|  \____/|__|   
        \/     \/     \/     \/           \/                   

=========================================================================
G00351238 -> Michael O'Grady

-------------------------------------------------------------------------
[>] Instructions:
-> ** To Parse both a File and URL the jsoup-1.14.3.jar libary must be run alongside the jar file with runner  ** (i.e. jsoup-1.14.3.jar file && wcloud.jar) **

> Run the following command in command prompt within the project directory:
java -cp ./wcloud.jar;./jsoup-1.14.3.jar ie.gmit.dip.Runner
-------------------------------------------------------------------------
[>] About
This application generates a word-cloud displaying the most prominent words with the highest frequency occurence 
in a larger font size, with differing styles and colours, also ignoring words within a text file called ignorewords.txt
assumed to be available in the current directory ( ignorewords.txt ). Image and frequency file are outputted to the project
directory unless the parsed file is located elsewhere, the output will be at that location.
/* Order of Process
 * 1) Parse in ignore words file into HashSet
 * 2) Parse from File/URL into HashMap 
 * 3) Find Frequency of words by using Counter
 * 4) Add Words and Frequency to Priority Queue
 * 5) Strip Punctuation, Sort Words and Frequency
 * 6) Update HashMap using containsKey and put
 * 7) Request Export of Frequency Table to a txt file
 * 7) Generate Word cloud png file
-------------------------------------------------------------------------
[>] Functionality
HashMap -> Interface used for Menu Commands
HashSet -> read in ignore words
HashMap -> map unique words
PriorityQueue -> build Freqency Table 
RandomNumberGeneration -> using ThreadLocalRandom API to decide fonts and colours.
Enums for ColourPalettes, Input Source, and BG Colour
-------------------------------------------------------------------------
[>] Main Features:

1. Parse Text from Text File
2. Parse Text from URL using Jsoup Java HTML Parser
3. Choice to Set Word Count to Display 
4. Choice to Save File Name for image
5. Frequency table for Words Parsed and Count of Word Instance
-------------------------------------------------------------------------
[>] Additional Features:
1. Running times in (ms) displayed for reading in ignore file and creation of word cloud
2. Error handling with throw Exceptions.
3. Fully commented code
4. Big O break down for classes
5. Command line option to open image using java.awt.Desktop in default image viewer
-------------------------------------------------------------------------
[>] References: (in addition to commented in code citations) for design concepts, and code implementations.

- Url Parsing using Jsoup
 Java HTML Parser: https://jsoup.org/ | a Java library for working with real-world HTML parses HTML using DOM traversal or CSS selectors.
 https://zetcode.com/java/jsoup/
 Selector Syntax reference -> https://jsoup.org/cookbook/extracting-data/selector-syntax

- HashMap implemented Menu -> Commands driven by Functional Interface
 https://www.geeksforgeeks.org/hashmap-put-method-in-java/
 Week 8 Sets and Maps J.Healy 

- Image Opening with Default Viewer - java.awt.Desktop
 https://www.programcreek.com/java-api-examples/?class=java.awt.Desktop&method=isDesktopSupported

- Image Generator
 https://docs.oracle.com/javase/7/docs/api/java/awt/Graphics.html
 https://www.programcreek.com/java-api-examples/?api=javax.imageio.ImageWriter
 https://www.youtube.com/watch?v=zCiMlbu1-aQ
 https://docs.oracle.com/javase/7/docs/api/java/awt/FontMetrics.html
 Concept and code adapted for text sizing -> https://www.youtube.com/watch?v=n2UYy5IjpY8
 Draw string -> https://www.programcreek.com/java-api-examples/?class=java.awt.Graphics&method=drawString
 

- Frequency Table
 https://www.javatpoint.com/java-program-to-find-the-frequency-of-each-element-in-the-array
 https://www.geeksforgeeks.org/queue-poll-method-in-java/

- Random number generation using ThreadLocalRandom API
 https://docs.oracle.com/javase/7/docs/api/java/util/concurrent/ThreadLocalRandom.html
 https://www.youtube.com/watch?v=2aK9ZDI98P8